package MenorMultiplicacion;

import java.util.Scanner;

/** 
* @author sdelaot
*/
public class ProbadorDeSecuenciaMatricial {
    public static void main(String[] args) {
        int miN = 0;
        /*Scanner teclado = new Scanner( System.in );
        System.out.println();
        
        System.out.print( "Cuantas matrices tiene : " );
        miN = teclado.nextInt();
        
        System.out.println( "Introduzca los ordenes de cada matriz : " );
        int [] p = new int[miN + 1];
        
        for (int i = 0; i < miN + 1; i++) {
            System.out.print( "p[" + i + "] = " );
            p[i] = teclado.nextInt();
        }*/
        
        
        int[] p = ejemploC();
        System.out.println();
        SecuenciaMatricial secuenciaM = new SecuenciaMatricial();
        secuenciaM.ejecutarAlgoritmo(p.length - 1, p);
    }
    
    static int[] ejemploA(){
        int[] p = new int[5 + 1];
        p[0] = 5;
        p[1] = 5;
        p[2] = 20;
        p[3] = 10;
        p[4] = 90;
        p[5] = 10;
        return p;
    }
    
    static int[] ejemploB(){
        int[] p = new int[5 + 1];
        p[0] = 10;
        p[1] = 8;
        p[2] = 5;
        p[3] = 30;
        p[4] = 40;
        p[5] = 5;
        return p;
    }
    
    static int[] ejemploC(){
        int[] p = new int[3 + 1];
        p[0] = 3;
        p[1] = 2;
        p[2] = 5;
        p[3] = 4;
        return p;
    }
}
