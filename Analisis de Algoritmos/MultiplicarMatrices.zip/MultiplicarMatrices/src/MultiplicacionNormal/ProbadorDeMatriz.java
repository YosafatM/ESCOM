/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MultiplicacionNormal;

/**
* @author sdelaot
*/
public class ProbadorDeMatriz {
    public static void main(String[] args) {
        Matriz M1 = new Matriz( 2, 3 );
        Matriz M2 = new Matriz( 3, 2 );
        //System.out.println( M1 );
        
        M1.addElemento(0, 0, 2);
        M1.addElemento(0, 1, 3);
        M1.addElemento(0, 2, 5);
        M1.addElemento(1, 0, 7);
        M1.addElemento(1, 1, 2);
        M1.addElemento(1, 2, 4);
        System.out.println( M1 );
        
        //System.out.println( M2 );
        M2.addElemento(0, 0, 1);
        M2.addElemento(0, 1, 6);
        M2.addElemento(1, 0, 7);
        M2.addElemento(1, 1, 2);
        M2.addElemento(2, 0, 0);
        M2.addElemento(2, 1, -5);
        System.out.println( M2 );
        
        AritmeticaMatricial am = new AritmeticaMatricial();
        Matriz M3 = am.multiplicar(M1, M2);
        System.out.println( M3 );
    }
}