/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MultiplicacionStrassen;

/**
* @author sdelaot
*/
public class ProbadorDeStrassen {
    public static void main(String[] args) {
        int filaycolumna = 4;
        Strassen strassen = new Strassen(filaycolumna, filaycolumna);
        strassen.ejecutarAlgoritmo(0);
    }
}
