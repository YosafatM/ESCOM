/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplicadorgrande;

import java.math.BigInteger;
import matematica.MultiplicadorEntero;

/**
 * @author yosaf
 */
public class MultiplicadorGrande {
    
    public static void main(String[] args) {
        MultiplicadorEntero multiplicador = new MultiplicadorEntero();
        
        int resultadoEntero = multiplicador.multiplicar(2147483647, 3);
        System.out.println(resultadoEntero);
        
        long resultadoLong = multiplicador.multiplicar(2147483647L, 10L);
        System.out.println(resultadoLong);
        
        BigInteger resultadoBi = multiplicador.multiplicar(BigInteger.valueOf(487L), 
                BigInteger.valueOf(2));
        System.out.println(resultadoBi);
    }
    
}
