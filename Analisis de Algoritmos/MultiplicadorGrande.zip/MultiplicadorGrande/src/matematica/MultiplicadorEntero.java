package matematica;

import java.math.BigInteger;

/**
* @author Saul De La O Torres
*/
public class MultiplicadorEntero {
    //<editor-fold defaultstate="collapsed" desc="Multiplicacion int">
    public int multiplicar( int u, int v ) {
        int w, x, y, z;
        int n = obtenerMayorEnTamanioDeDigitos(u, v);
        
        if( esPequenio( n ) ) {
            return u * v;
        }
        
        // Dividir
        int s = n / 2;
        double temporal = Math.pow(10, s);
        w = u / (int)temporal;
        x = u % (int)temporal;
        y = v / (int)temporal;
        z = v % (int)temporal;
        
        // combinar
        return multiplicar( w, y )*(int)Math.pow(10, 2*s) +
        (multiplicar( w, z )+multiplicar( x, y ))*(int)Math.pow(10, s) +
        multiplicar( x, z );
    }
    
    private int obtenerMayorEnTamanioDeDigitos(int x, int y) {
        String xString = "" + x;
        String yString = "" + y;
        
        if( xString.length()>=yString.length() ) {
            return xString.length();
        }
        
        return yString.length();
    }
    
    /**
    * El numero es pequenio si es de un digito
    * @param x el entero donde se verifica el numero de digitos que tiene
    * @return devuelve true si es pequeño y false en caso contrario
    */
    private boolean esPequenio( int numero ) {
        String xString = "" + numero;
        return xString.length()<=1;
    }
    // </editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Multiplicacion long">
    public long multiplicar( long u, long v ) {
        long w, x, y, z;
        long n = obtenerMayorEnTamanioDeDigitos(u, v);
        
        if( esPequenio( n ) ) {
            return u * v;
        }
        
        // Dividir
        long s = n / 2;
        double temporal = Math.pow(10, s);
        w = u / (long)temporal;
        x = u % (long)temporal;
        y = v / (long)temporal;
        z = v % (long)temporal;
        
        // combinar
        return multiplicar( w, y )*(long)Math.pow(10, 2*s) +
        (multiplicar( w, z )+multiplicar( x, y ))*(long)Math.pow(10, s) +
        multiplicar( x, z );
    }
    
    private long obtenerMayorEnTamanioDeDigitos(long x, long y) {
        String xString = "" + x;
        String yString = "" + y;
        
        if( xString.length()>=yString.length() ) {
            return xString.length();
        }
        
        return yString.length();
    }
    
    /**
    * El numero es pequenio si es de un digito
    * @param x el entero donde se verifica el numero de digitos que tiene
    * @return devuelve true si es pequeño y false en caso contrario
    */
    private boolean esPequenio( long numero ) {
        String xString = "" + numero;
        return xString.length()<=1;
    }
    // </editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Multiplicacion BigInteger">
    public BigInteger multiplicar( BigInteger u, BigInteger v ) {
        BigInteger w, x, y, z;
        int n = obtenerMayorEnTamanioDeDigitos(u, v);
        
        if( esPequenio( n ) ) {
            return u.multiply(v);
        }
        
        // Dividir
        long s = n / 2;
        double temporal = Math.pow(10, s);
        w = u.divide(BigInteger.valueOf((long)temporal));
        x = u.mod(BigInteger.valueOf((long)temporal));
        y = v.divide(BigInteger.valueOf((long)temporal));
        z = v.mod(BigInteger.valueOf((long)temporal));
        
        // combinar
        return multiplicar( w, y ).multiply(BigInteger.valueOf((long)Math.pow(10, 2*s)))
                .add((multiplicar( w, z ).add(multiplicar( x, y ))).multiply(BigInteger.valueOf((long)Math.pow(10, s))))
                .add(multiplicar( x, z ));
    }
    
    private int obtenerMayorEnTamanioDeDigitos(BigInteger x, BigInteger y) {        
        if( x.bitLength() >= y.bitLength() ) {
            return x.bitLength();
        }
        
        return y.bitLength();
    }
    
    /**
    * El numero es pequenio si es de un digito
    * @param x el entero donde se verifica el numero de digitos que tiene
    * @return devuelve true si es pequeño y false en caso contrario
    */
    private boolean esPequenio( BigInteger numero ) {
        String xString = "" + numero;
        return xString.length()<=1;
    }
    // </editor-fold>
}
